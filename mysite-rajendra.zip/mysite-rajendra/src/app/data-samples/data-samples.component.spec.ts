import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DataSamplesComponent } from './data-samples.component';

describe('DataSamplesComponent', () => {
  let component: DataSamplesComponent;
  let fixture: ComponentFixture<DataSamplesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DataSamplesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DataSamplesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
