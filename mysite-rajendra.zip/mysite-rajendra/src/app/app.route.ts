import {Routes} from '@angular/router';
import { AppComponent } from './app.component';
import { HomeComponentComponent } from './home-component/home-component.component';
import { AboutmeComponentComponent } from './aboutme-component/aboutme-component.component';
import { AboutworkComponentComponent } from './aboutwork-component/aboutwork-component.component';
import { BlogComponentComponent } from './blog-component/blog-component.component';
import { ContactComponentComponent } from './contact-component/contact-component.component';
import { DataSamplesComponent } from "./data-samples/data-samples.component";

export const appRoutes: Routes = [
    {
        path:'home',
        component: HomeComponentComponent
    },
    {
        path:'about',
        component: AboutmeComponentComponent
    },
     {
        path:'work',
        component:AboutworkComponentComponent
    },
    {
        path:'blog',
        component:BlogComponentComponent
    },
    {
        path:'contact',
        component:ContactComponentComponent
    },
    {
        path:'other',
        component:DataSamplesComponent
    },
    
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: '**', redirectTo: 'home', pathMatch: 'full' }
   ];


    