import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutme-component',
  templateUrl: './aboutme-component.component.html',
  styleUrls: ['./aboutme-component.component.css']
})
export class AboutmeComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
