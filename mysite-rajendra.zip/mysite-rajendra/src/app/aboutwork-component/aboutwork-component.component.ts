import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboutwork-component',
  templateUrl: './aboutwork-component.component.html',
  styleUrls: ['./aboutwork-component.component.css']
})
export class AboutworkComponentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
