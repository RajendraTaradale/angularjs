import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboutworkComponentComponent } from './aboutwork-component.component';

describe('AboutworkComponentComponent', () => {
  let component: AboutworkComponentComponent;
  let fixture: ComponentFixture<AboutworkComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboutworkComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboutworkComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
