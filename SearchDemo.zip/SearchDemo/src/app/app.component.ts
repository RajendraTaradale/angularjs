import { Component, OnInit,Input } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { NouisliderModule } from 'ng2-nouislider';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit {
  registerForm: FormGroup;
 
  flightData:any[] = [];
  filterData:any;

  tempX:any;
  tempY:any;
  tempResult:any;

  _DefaultRane: any;
get someRange(): any {
    return this._DefaultRane;
}

@Input('allowDay')
set someRange(value: any) {
    this._DefaultRane = value;
    this.GetFlightByRange();
}

  
    submitted = false;
    apiUrl = './app/Data.json';
    constructor(private formBuilder: FormBuilder, private http: HttpClient) {
      this.someRange = [ 0, 5000 ];
      this.http.get<any>('./assets/Data.json').subscribe(
        data => {
        this.flightData = data;
        }
      );
    }
 
    ngOnInit() {
        this.registerForm = this.formBuilder.group({
            From: ['', Validators.required],
            To: ['', Validators.required],
            Date: ['', Validators.required],
            RDate: ['', '']
        });
       
    }
 
    // convenience getter for easy access to form fields
    get f() { return this.registerForm.controls; }
    onDateChanged(value){
      alert(value);
    }

    GetFormatedDate(date){
      if(date != null) {
      const dt = date.split('-');
       return date = dt[1] + '/' + dt[2] + '/' + dt[0];
      }
    }
    ChangeRange() {
      alert(this.someRange);
    }
    onSubmit() {
        this.submitted = true;
           if (this.registerForm.invalid) {
            return;
        }
      // Filter for Location
       const result = this.flightData.filter(word => word['from'] === this.registerForm.value.From
       && word['to'] === this.registerForm.value.To
       && word['date'] === this.GetFormatedDate(this.registerForm.value.Date));
       this.filterData = result;

    }

    GetFlightByRange() {
      // Filter by Range
       const result = this.flightData.filter(word => word['flightRate'] < this.someRange[0] || word['flightRate'] < this.someRange[1]);
       this.filterData = result;
      // if (this.tempX == null && this.tempY == null){
      //   this.tempX = this.someRange[0];
      //   this.tempY = this.someRange[1];
      //  const result = this.flightData.filter(word => word['flightRate'] < this.someRange[0] || word['flightRate'] > this.someRange[1]);
      //  this.filterData = result;
      //  this.tempResult = result;
      // }else{

      //   if(this.tempX !== this.someRange[0]) {
      //     this.tempResult.filter(word => word['flightRate'] < this.someRange[0]);
      //     this.filterData=this.tempResult;
      //   }
      //   if(this.tempY !== this.someRange[1]) {
      //     this.tempResult.filter(word => word['flightRate'] < this.someRange[1]);
      //     this.filterData=this.tempResult;
      //   }


      }
    }

}
